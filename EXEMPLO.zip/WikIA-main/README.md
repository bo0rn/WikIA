# WikIA
Este é um projeto dedicado a realização do Trabalho de Conclusão de Curso (TCC), necessário para concluirmos nosso ensino médio integrado ao curso de Desenvolvimento de Sistemas. A ideia é criar um site informativo que abrange uma alta gama de conteúdos educacionais sobre a Inteligência Artificial, além de ensinar os beneficios de usa-lá de forma inteligente, equilibrada e orientada.


# LICENÇA
Todos os direitos do projeto são reservados e utilizados para fins educacionais.


## Animações e navegação

- `ia/motion.js`: transições de navegação e animação gradual dos cards usando **JavaScript nativo (Web Animations API)**, além de controle do menu móvel.
- `docs/JS/motion.js`: revelação de conteúdo ao rolar usando `IntersectionObserver` e transições entre páginas HTML.
- O CSS continua responsável apenas pelas interações visuais básicas (hover, foco, cores).
- Sem instalação de dependências; abra `ia/index.html` ou `docs/index.html` em um servidor local.
- As animações respeitam a preferência de acessibilidade "Reduzir movimento".
