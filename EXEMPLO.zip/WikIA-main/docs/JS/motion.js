/**
 * WikIA — movimento progressivo e navegação suave entre arquivos HTML.
 * Sem dependências; com fallback automático e respeito a movimento reduzido.
 */
(() => {
  'use strict';

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

  function initReveals() {
    if (reduceMotion.matches || !('IntersectionObserver' in window)) return;

    const elements = document.querySelectorAll(
      'main > section, main > article, main > .text-box, main > .conteudo, .containerConteudo > .bloco-conteudo'
    );
    if (!elements.length) return;

    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }, { threshold: 0.08, rootMargin: '0px 0px -16px 0px' });

    elements.forEach((element, i) => {
      element.classList.add('motion-reveal');
      element.style.setProperty('--reveal-delay', `${(i % 3) * 65}ms`);
      observer.observe(element);
    });
    document.documentElement.classList.add('motion-enabled');
  }

  function initPageTransitions() {
    document.addEventListener('click', event => {
      const anchor = event.target.closest('a[href]');
      if (!anchor || event.defaultPrevented || event.button !== 0 ||
          event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ||
          anchor.hasAttribute('download') || (anchor.target && anchor.target !== '_self') ||
          reduceMotion.matches) return;

      const url = new URL(anchor.href, window.location.href);
      if (url.origin !== window.location.origin ||
          !url.pathname.endsWith('.html') ||
          url.pathname === window.location.pathname) return;

      event.preventDefault();
      document.body.classList.add('motion-leaving');
      window.setTimeout(() => window.location.assign(url.href), 185);
    });

    // Remove o estado de saída ao restaurar uma página pelo histórico (bfcache).
    window.addEventListener('pageshow', () => {
      document.body.classList.remove('motion-leaving');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initReveals();
      initPageTransitions();
    }, { once: true });
  } else {
    initReveals();
    initPageTransitions();
  }
})();
