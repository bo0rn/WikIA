const botaoAbrir = document.querySelector("header > button");
const botaoFechar = document.querySelector("header nav.mobile button");
const body = document.body;
const nav = document.querySelector("header nav.mobile");

if (botaoAbrir && botaoFechar && nav) {
    botaoAbrir.addEventListener('click', abrirMenu);
    botaoFechar.addEventListener('click', fecharMenu);
}

function abrirMenu() {
    body.classList.add('escurecer');
    nav.classList.add('abrir');
}

function fecharMenu() {
    body.classList.remove('escurecer');
    nav.classList.remove('abrir');
}

// Acessibilidade e fechamento do menu sem depender de bibliotecas.
if (botaoAbrir && botaoFechar && nav) {
    botaoAbrir.setAttribute('aria-label', 'Abrir menu');
    botaoAbrir.setAttribute('aria-expanded', 'false');
    botaoFechar.setAttribute('aria-label', 'Fechar menu');
    const atualizarMenu = () => {
        const aberto = nav.classList.contains('abrir');
        botaoAbrir.setAttribute('aria-expanded', String(aberto));
        nav.setAttribute('aria-hidden', String(!aberto));
    };
    const observar = new MutationObserver(atualizarMenu);
    observar.observe(nav, { attributes: true, attributeFilter: ['class'] });
    atualizarMenu();
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && nav.classList.contains('abrir')) {
            fecharMenu();
            botaoAbrir.focus();
        }
    });
    nav.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', fecharMenu);
    });
}
